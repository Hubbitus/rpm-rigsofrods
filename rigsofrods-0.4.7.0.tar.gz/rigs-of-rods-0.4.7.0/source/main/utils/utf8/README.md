UTF-8 CPP library
=================

Homepage: http://utfcpp.sourceforge.net/

Repository: https://github.com/nemtrif/utfcpp

License: Boost Software License 1.0
